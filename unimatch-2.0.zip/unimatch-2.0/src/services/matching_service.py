"""MatchingService - Lógica principal de matching (UniMatch 2.0)

Este servicio integra:
- PostgreSQL: usuarios, temas, horarios
- Neo4j: proximidad indirecta
- Redis: caché de recomendaciones

El objetivo es demostrar el enfoque políglota para Bases de Datos II.
"""

from src.dao.postgres.usuario_dao import UsuarioDAO
from src.dao.postgres.match_dao import MatchDAO
from src.dao.postgres.horario_dao import HorarioDAO
from src.dao.redis.cache_dao import CacheDAO
from src.dao.neo4j.recommendation_dao import RecommendationDAO
from src.dao.postgres.postgres_connection import PostgresConnection


class MatchingService:

    def __init__(self):
        self.usuario_dao = UsuarioDAO()
        self.match_dao = MatchDAO()
        self.horario_dao = HorarioDAO()
        self.cache_dao = CacheDAO()
        self.recommendation_dao = RecommendationDAO()

    def calcular_puntaje_nivel(self, nivel_a, nivel_b):
        niveles = {"basico": 1, "intermedio": 2, "avanzado": 3}
        diff = abs(niveles[nivel_a] - niveles[nivel_b])

        if diff == 0:
            return 20
        if diff == 1:
            return 10
        return 0

    def calcular_puntaje_objetivo(self, obj_a, obj_b):
        if (obj_a == "aprender" and obj_b == "explicar") or (obj_a == "explicar" and obj_b == "aprender"):
            return 20
        if obj_a == obj_b and obj_a == "practicar":
            return 15
        if obj_a == obj_b and obj_a == "repasar":
            return 10
        if obj_a == obj_b:
            return 10
        return 0

    def calcular_puntaje_idioma(self, idioma_a, idioma_b):
        return 10 if idioma_a == idioma_b else 0

    def existe_solapamiento_horario(self, user_id_a, user_id_b):
        """Implementación simplificada: compara día y solapamiento de horas sin convertir zonas horarias.
        En un sistema real, se debería convertir a UTC para comparación correcta.
        """

        horarios_a = self.horario_dao.listar_horarios_usuario(user_id_a)
        horarios_b = self.horario_dao.listar_horarios_usuario(user_id_b)

        for ha in horarios_a:
            for hb in horarios_b:
                if ha["dia"] != hb["dia"]:
                    continue

                # Solapamiento simple (hora_inicio < otra_fin) y (hora_fin > otra_inicio)
                if ha["hora_inicio"] < hb["hora_fin"] and ha["hora_fin"] > hb["hora_inicio"]:
                    return True

        return False

    def puntaje_grafo(self, user_id_a, user_id_b):
        distancia = self.recommendation_dao.distancia_entre_usuarios(user_id_a, user_id_b)

        if distancia is None:
            return 0
        if distancia == 2:
            return 10
        if distancia == 3:
            return 5
        return 0

    def obtener_candidatos_postgres(self, user_id, topic_id):
        """Obtiene candidatos por tema en común."""

        sql = """
        SELECT u.id_usuario, u.nombre, u.pais, u.idioma,
               ut.nivel, ut.objetivo
        FROM USUARIO u
        JOIN USUARIO_TEMA ut ON ut.id_usuario = u.id_usuario
        WHERE ut.id_tema = %s
          AND u.id_usuario <> %s;
        """

        with PostgresConnection.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (topic_id, user_id))
                return cur.fetchall()

    def obtener_datos_usuario_tema(self, user_id, topic_id):
        sql = """
        SELECT nivel, objetivo
        FROM USUARIO_TEMA
        WHERE id_usuario = %s AND id_tema = %s;
        """

        with PostgresConnection.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (user_id, topic_id))
                return cur.fetchone()

    def recomendar_matches(self, user_id, topic_id, limit=10):
        """Genera recomendaciones para un usuario y un tema específico."""

        # 1) Verificar caché Redis
        cache = self.cache_dao.obtener_recomendaciones(user_id)
        if cache is not None:
            return cache[:limit]

        # 2) Obtener datos del usuario actual
        user = self.usuario_dao.obtener_por_id(user_id)
        if user is None:
            raise Exception("Usuario inexistente.")

        ut = self.obtener_datos_usuario_tema(user_id, topic_id)
        if ut is None:
            raise Exception("El usuario no tiene registrado el tema solicitado.")

        nivel_user = ut["nivel"]
        objetivo_user = ut["objetivo"]

        # 3) Obtener candidatos
        candidatos = self.obtener_candidatos_postgres(user_id, topic_id)

        recomendaciones = []

        for c in candidatos:
            if self.match_dao.existe_match_activo(user_id, c["id_usuario"], topic_id):
                continue

            puntaje = 50  # tema común

            puntaje += self.calcular_puntaje_nivel(nivel_user, c["nivel"])
            puntaje += self.calcular_puntaje_objetivo(objetivo_user, c["objetivo"])
            puntaje += self.calcular_puntaje_idioma(user["idioma"], c["idioma"])

            if self.existe_solapamiento_horario(user_id, c["id_usuario"]):
                puntaje += 20

            puntaje += self.puntaje_grafo(user_id, c["id_usuario"])

            recomendaciones.append({
                "id_usuario": c["id_usuario"],
                "nombre": c["nombre"],
                "pais": c["pais"],
                "idioma": c["idioma"],
                "puntaje": puntaje
            })

        recomendaciones.sort(key=lambda x: x["puntaje"], reverse=True)

        # 4) Guardar caché en Redis
        self.cache_dao.guardar_recomendaciones(user_id, recomendaciones)

        return recomendaciones[:limit]

    def confirmar_match(self, user_id_1, user_id_2, topic_id, score):
        """Crea match persistente en PostgreSQL y registra relación en Neo4j."""

        if self.match_dao.existe_match_activo(user_id_1, user_id_2, topic_id):
            raise Exception("Ya existe un match activo para este par y tema.")

        id_match = self.match_dao.crear_match(user_id_1, user_id_2, topic_id, score, estado="pendiente")

        # Registrar en grafo
        self.recommendation_dao.registrar_match_en_grafo(user_id_1, user_id_2, topic_id, score)

        return id_match
