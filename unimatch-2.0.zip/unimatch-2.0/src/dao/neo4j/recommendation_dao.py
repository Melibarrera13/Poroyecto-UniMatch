"""RecommendationDAO - Consultas de recomendación en Neo4j

Este DAO busca usuarios cercanos por temas compartidos.
"""

from src.dao.neo4j.neo4j_connection import Neo4jConnection


class RecommendationDAO:

    def usuarios_por_tema_compartido(self, user_id, limit=20):
        """Usuarios que estudian los mismos temas (distancia 2)."""

        query = """
        MATCH (u:User {userId: $userId})-[:STUDIES]->(:Topic)<-[:STUDIES]-(other:User)
        WHERE other.userId <> $userId
        RETURN other.userId AS userId, other.nombre AS nombre
        LIMIT $limit;
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            result = session.run(query, userId=user_id, limit=limit)
            return [r.data() for r in result]

    def distancia_entre_usuarios(self, user_id_1, user_id_2):
        """Obtiene distancia mínima en el grafo entre dos usuarios."""

        query = """
        MATCH (u1:User {userId: $u1}), (u2:User {userId: $u2})
        MATCH p = shortestPath((u1)-[*..3]-(u2))
        RETURN length(p) AS distancia;
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            record = session.run(query, u1=user_id_1, u2=user_id_2).single()
            if record is None:
                return None
            return record["distancia"]

    def registrar_match_en_grafo(self, user_id_1, user_id_2, topic_id, score):
        query = """
        MATCH (u1:User {userId: $u1}), (u2:User {userId: $u2})
        MERGE (u1)-[:MATCHED_WITH {topicId: $topicId}]->(u2)
        SET (u1)-[:MATCHED_WITH {topicId: $topicId}]->(u2).score = $score,
            (u1)-[:MATCHED_WITH {topicId: $topicId}]->(u2).createdAt = datetime();
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            session.run(query, u1=user_id_1, u2=user_id_2, topicId=topic_id, score=score)
            return True
