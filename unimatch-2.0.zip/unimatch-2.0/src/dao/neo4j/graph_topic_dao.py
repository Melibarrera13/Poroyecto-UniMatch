"""GraphTopicDAO - Persistencia de nodos Topic en Neo4j"""

from src.dao.neo4j.neo4j_connection import Neo4jConnection


class GraphTopicDAO:

    def crear_tema_nodo(self, topic_id, nombre, area):
        query = """
        MERGE (t:Topic {topicId: $topicId})
        SET t.nombre = $nombre,
            t.area = $area
        RETURN t;
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            result = session.run(query, topicId=topic_id, nombre=nombre, area=area)
            return result.single()

    def relacionar_temas(self, topic_id_1, topic_id_2, weight=0.5):
        query = """
        MATCH (t1:Topic {topicId: $t1}), (t2:Topic {topicId: $t2})
        MERGE (t1)-[:RELATED_TO]->(t2)
        SET (t1)-[:RELATED_TO]->(t2).weight = $weight,
            (t1)-[:RELATED_TO]->(t2).createdAt = datetime();
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            session.run(query, t1=topic_id_1, t2=topic_id_2, weight=weight)
            return True
