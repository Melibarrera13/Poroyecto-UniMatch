"""Neo4j Connection - UniMatch 2.0"""

from neo4j import GraphDatabase
from src.config.neo4j_config import NEO4J_CONFIG


class Neo4jConnection:

    @staticmethod
    def get_driver():
        return GraphDatabase.driver(
            NEO4J_CONFIG["uri"],
            auth=(NEO4J_CONFIG["user"], NEO4J_CONFIG["password"])
        )
