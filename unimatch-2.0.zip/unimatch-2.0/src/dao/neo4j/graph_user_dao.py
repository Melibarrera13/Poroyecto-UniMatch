"""GraphUserDAO - Persistencia de nodos User en Neo4j"""

from src.dao.neo4j.neo4j_connection import Neo4jConnection


class GraphUserDAO:

    def crear_usuario_nodo(self, user_id, nombre, pais, idioma):
        query = """
        MERGE (u:User {userId: $userId})
        SET u.nombre = $nombre,
            u.pais = $pais,
            u.idioma = $idioma
        RETURN u;
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            result = session.run(query, userId=user_id, nombre=nombre, pais=pais, idioma=idioma)
            return result.single()

    def relacionar_usuario_universidad(self, user_id, university_id, university_name):
        query = """
        MERGE (u:User {userId: $userId})
        MERGE (univ:University {universityId: $universityId})
        SET univ.nombre = $universityName
        MERGE (u)-[:BELONGS_TO {createdAt: datetime()}]->(univ);
        """

        driver = Neo4jConnection.get_driver()
        with driver.session() as session:
            session.run(query, userId=user_id, universityId=university_id, universityName=university_name)
            return True
