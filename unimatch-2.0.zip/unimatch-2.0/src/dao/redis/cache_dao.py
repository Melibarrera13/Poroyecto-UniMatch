"""CacheDAO - Caché de recomendaciones (Redis)

Key: cache:matches:{userId}
Tipo sugerido: LIST (JSON strings)
"""

import json
from src.dao.redis.redis_connection import RedisConnection
from src.config.redis_config import CACHE_TTL_SECONDS


class CacheDAO:

    def guardar_recomendaciones(self, user_id, recomendaciones):
        """recomendaciones: lista de dicts"""
        client = RedisConnection.get_client()
        key = f"cache:matches:{user_id}"

        client.delete(key)

        for rec in recomendaciones:
            client.rpush(key, json.dumps(rec))

        client.expire(key, CACHE_TTL_SECONDS)
        return True

    def obtener_recomendaciones(self, user_id):
        client = RedisConnection.get_client()
        key = f"cache:matches:{user_id}"

        if not client.exists(key):
            return None

        data = client.lrange(key, 0, -1)
        return [json.loads(x) for x in data]

    def invalidar_cache(self, user_id):
        client = RedisConnection.get_client()
        key = f"cache:matches:{user_id}"
        return client.delete(key) > 0
