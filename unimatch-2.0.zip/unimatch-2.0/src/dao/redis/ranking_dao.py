"""RankingDAO - Ranking de temas más consultados (Redis)

Key: ranking:topics
Tipo: SORTED SET
"""

from src.dao.redis.redis_connection import RedisConnection


class RankingDAO:

    def incrementar_busqueda_tema(self, nombre_tema):
        client = RedisConnection.get_client()
        key = "ranking:topics"
        client.zincrby(key, 1, nombre_tema)
        return True

    def top_temas(self, top_n=10):
        client = RedisConnection.get_client()
        key = "ranking:topics"
        return client.zrevrange(key, 0, top_n - 1, withscores=True)
