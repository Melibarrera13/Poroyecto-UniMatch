"""SessionDAO - Gestión de sesiones activas (Redis)

Clave: session:{userId}
Tipo: HASH
"""

from src.dao.redis.redis_connection import RedisConnection
from src.config.redis_config import SESSION_TTL_SECONDS


class SessionDAO:

    def crear_sesion(self, user_id, token):
        client = RedisConnection.get_client()
        key = f"session:{user_id}"

        client.hset(key, mapping={
            "token": token
        })

        client.expire(key, SESSION_TTL_SECONDS)
        return True

    def obtener_sesion(self, user_id):
        client = RedisConnection.get_client()
        key = f"session:{user_id}"

        if not client.exists(key):
            return None

        return client.hgetall(key)

    def eliminar_sesion(self, user_id):
        client = RedisConnection.get_client()
        key = f"session:{user_id}"
        return client.delete(key) > 0
