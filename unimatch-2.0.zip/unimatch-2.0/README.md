# UniMatch 2.0 — Plataforma Global de Match Académico por Temas

**UniMatch 2.0** es una aplicación tipo “Tinder académico” que conecta estudiantes a nivel global según el **tema exacto** que están estudiando, su **nivel**, **objetivo**, **idioma** y **disponibilidad horaria** (incluyendo zona horaria).

Este repositorio corresponde a un **proyecto universitario de Bases de Datos II**, diseñado para demostrar un enfoque **políglota** con tres tecnologías:

- **PostgreSQL** (relacional): persistencia transaccional y datos estructurados.
- **Redis** (clave-valor): caché, sesiones y rankings temporales.
- **Neo4j** (grafo): relaciones usuario–tema y recomendaciones indirectas.

---

## 1. Objetivos del repositorio

Este repositorio permite que un desarrollador pueda:

- Comprender el problema y el alcance del producto.
- Levantar y poblar la base de datos **PostgreSQL**.
- Comprender cómo integrar **Redis** y **Neo4j**.
- Entender el diseño de cada base de datos y su justificación.
- Implementar y reutilizar la **capa DAO** (Data Access Object).
- Analizar el flujo de **matching** y su algoritmo de puntaje.

---

## 2. Estructura del repositorio

```
unimatch-2.0/
├── README.md
├── docs/
├── diagrams/
├── sql/
├── src/
└── api/
```

---

## 3. Documentación principal

Toda la documentación está en `docs/`:

- Caso de estudio
- Problema
- Monetización
- Especificaciones del producto
- Modelo políglota
- MER
- Diccionario de datos
- Reglas de negocio
- Algoritmo de matching
- Arquitectura
- Índices y optimización
- Seguridad y privacidad

---

## 4. Requisitos de ejecución (entorno local)

### 4.1 PostgreSQL
- PostgreSQL 14+
- Ejecutar scripts de `/sql/`

### 4.2 Redis
- Redis 6+
- Se utiliza para sesiones, caché y ranking.

### 4.3 Neo4j
- Neo4j 5+
- Se utiliza para modelado de relaciones y recomendaciones.

---

## 5. Instalación rápida (base de datos)

### 5.1 Crear base y esquema en PostgreSQL

```bash
createdb unimatch
psql -d unimatch -f sql/schema_postgresql.sql
psql -d unimatch -f sql/indices.sql
psql -d unimatch -f sql/seed_data.sql
```

### 5.2 Consultas de matching

```bash
psql -d unimatch -f sql/queries_matching.sql
```

---

## 6. Capa DAO (src/)

El repositorio incluye una implementación de referencia en **Python**, organizada en:

- DAO PostgreSQL
- DAO Redis
- DAO Neo4j
- Servicio de matching

Los archivos contienen:
- configuración de conexión
- consultas SQL/Cypher/Redis
- métodos CRUD
- métodos de recomendación y ranking

---

## 7. Diagrama y modelo

Los diagramas se encuentran en `diagrams/` en formato Markdown y Mermaid.

---

## 8. Nota académica

Este repositorio es un material de estudio para la materia **Bases de Datos II**.
No incluye frontend ni despliegue productivo; el foco está en:

- Modelado de datos
- Consistencia e integridad
- Arquitectura políglota
- DAO y consultas

---

## 9. Autoría

Proyecto: **UniMatch 2.0**  
Materia: **Bases de Datos II**  
Año: 2026
